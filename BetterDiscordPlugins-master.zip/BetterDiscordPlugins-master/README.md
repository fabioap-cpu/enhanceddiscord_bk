# BetterDiscordPlugins
First encounter with js?

>Better VoiceMessage plugin: https://github.com/MKSx/Send-Audio-Plugin-BetterDiscord

>Better Emotes plugin: https://github.com/An00nymushun/DiscordFreeEmojis

Discord: oSumAtrIX#7490

# How to use the plugins
1. Get [Better-](https://enhanceddiscord.com) or [Enhanced Discord](https://betterdiscord.net/) and install it
1. Download the plugins (and [Zere's Library](https://raw.githubusercontent.com/rauenzi/BDPluginLibrary/master/release/0PluginLibrary.plugin.js) and put them into your plugins folder (For BD it's in AppData/Roaming/BetterDiscord/plugins and for ED its in the same folder as where you installed ED)
1. Visit the discord settings
	* If you are using ED, then enable the switch to load BD plugins. ![Image](https://i.imgur.com/BPzTLS4.png)
1. Restart Discord and enable the plugins in the discord settings > Plugins
